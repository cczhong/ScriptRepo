#!/usr/bin/perl -w
use strict;

my $config = shift;

if(!defined $config)  {
  print "Usage: perl SeqTrim.pl run_config\n";
  print "=================================\n";
  print "Example of a run_config file: please do not include lines in parenthesis \(\)\n\n";
  print "#folder=/home/cczhong/Works/Perera/SeqTrim/Data/test\n";
  print "(MANDATORY: the folder for output, it must exists before running the program)\n";
  print "#adapter=/home/cczhong/Works/Perera/SeqTrim/Data/test/adapter.fa\n";
  print "(OPTIONAL: the FASTA file for adapter sequences)\n";
  print "#fastqcEXE=/home/cczhong/Tools/FastQC/fastqc\n";
  print "(MANDATORY: the FastQC executable file)\n";
  print "#trimmomaticEXE=/home/cczhong/Tools/Trimmomatic-0.36/trimmomatic-0.36.jar\n";
  print "(MANDATORY: the Trimmomatic executable file)\n";
  print "#SE=/home/cczhong/Works/Perera/SeqTrim/Data/test/test.fastq.gz\n";
  print "(OPTIONAL: a single-end FASTQ file to be processed; must provide full path; must be gunzipped; must be ended with extension \".fastq.gz\")\n";
  print "(the SE entry can occur multiple times in the run config file)\n";
  print "#PE=/home/cczhong/Works/Perera/SeqTrim/Data/test/test_1.fastq.gz,/home/cczhong/Works/Perera/SeqTrim/Data/test/test_2.fastq.gz\n";
  print "(OPTIONAL: two pair-end FASTQ files to be processed; separated by a comma \",\")\n";
  print "(must provide full paths; must be gunzipped; must be ended with extension \".fastq.gz\")\n";
  print "(the PE entry can occur multiple times in the run config file)\n";
  print "\n";
  exit;
}

# parsing run config
my $folder;
my $adapter = "XXX";
my $fastqcEXE;
my $trimmomaticEXE;

open my $CIN, "<$config" or die "Cannot open config file: $!\n";
my @toProcess;
while(<$CIN>) {
  chomp;
  if(/\#folder\=(\S+)/)  {
    $folder = $1;
  }
  if(/\#adapter\=(\S+)/)  {
    $adapter = $1;
  }
  if(/\#fastqcEXE\=(\S+)/)  {
    $fastqcEXE = $1;
  }
  if(/\#trimmomaticEXE\=(\S+)/)  {
    $trimmomaticEXE = $1;
  }
  if(/\#SE\=(\S+)/)  {
    my @decom; push @decom, $1;
    push @toProcess, \@decom;
  }
  if(/\#PE\=(\S+)/)  {
    my @decom = split /\,/, $1;
    push @toProcess, \@decom;
  }
}
close $CIN;


if(!-e "$folder/FastQCResults")  {
  mkdir "$folder/FastQCResults" or die "Cannot create FastQC result directory: $!\n";
}

if(!-e "$folder/LogFiles")  {
  mkdir "$folder/LogFiles" or die "Cannot create log directory: $!\n";
}

if(!-e "$folder/Processed")  {
  mkdir "$folder/Processed" or die "Cannot create processed data directory: $!\n";
}

chdir "$folder" or die "Cannot enter data directory: $!\n";
my $k;
for(my $k = 0; $k < scalar(@toProcess); ++ $k)  {

  my $file1; my $file2;
  my $stem1; my $stem2;
  my $tag = -1;

  if(scalar(@{$toProcess[$k]}) == 1) {
    $tag = 0; # SE
    $file1 = ${$toProcess[$k]}[0];
    print "### SE case: $file1\n";
    
  } elsif(scalar(@{$toProcess[$k]}) == 2) {
    $tag = 1; # PE
    $file1 = ${$toProcess[$k]}[0];
    $file2 = ${$toProcess[$k]}[1];
    print "### PE case: $file1 and $file2\n";
  } else  {
    print "### Error in run_config file: ";
    print "@{$toProcess[$k]}, case skipped.\n";
    next;
  }

  $file1 =~ /.*\/(.*)/; $stem1 = $1; $stem1 =~ s/\.fastq\.gz//g;
  if($tag == 1)  {
    $file2 =~ /.*\/(.*)/; $stem2 = $1; $stem2 =~ s/\.fastq\.gz//g;
  }

  if($tag == 0)  {    # SE case
    # run fastqc
    system "/usr/bin/time -v $fastqcEXE $file1 --extract -o ./FastQCResults >& LogFiles/$stem1\_SE.fastqc.log";
    # generate the sequences to remove
    if(defined "$adapter" && -e "$adapter") {
      system "cp $adapter ./Processed/seqToTrim.$stem1.SE.fa";
    } else  {
      system "rm ./Processed/seqToTrim.$stem1.SE.fa" if -e "./Processed/seqToTrim.$stem1.SE.fa";
      system "touch ./Processed/seqToTrim.$stem1.SE.fa";
    }
    # parse the overrepresented sequences
    open my $FIN, "<./FastQCResults/$stem1\_fastqc/fastqc_data.txt" or die "Cannot open fastqc data file: $!\n";
    my @content;
    while(<$FIN>) {
      chomp;
      push @content, $_;
    }
    close $FIN;
    my $i;
    for($i = 0; $i < scalar(@content); ++ $i) {
      if($content[$i] =~ /\>\>Overrepresented sequences/)  {
        $i += 2; my $j = 0;
        while(!($content[$i] =~ /\>\>END\_MODULE/)) {
          system "echo \">\"overrepresented_seq_$j >>./Processed/seqToTrim.$stem1.SE.fa";
          my @decom = split /\t/, $content[$i];
          system "echo $decom[0] >>./Processed/seqToTrim.$stem1.SE.fa";
          ++ $i; ++ $j;
        }
        last;
      }
    }
    # run Trimmomatic to remove the overrepresented sequences
    system "/usr/bin/time -v java -jar $trimmomaticEXE SE $file1 ./Processed/$stem1.trimmed.gz ILLUMINACLIP:./Processed/seqToTrim.$stem1.SE.fa:2:30:10 LEADING:30 TRAILING:30 SLIDINGWINDOW:4:30 MINLEN:35 -threads 8 >&LogFiles/$stem1.SE.trimmomatic.log";
  } 
  elsif($tag == 1) {  # SE case
    # run fastqc
    system "/usr/bin/time -v $fastqcEXE $file1 $file2 --extract -o ./FastQCResults >& LogFiles/$stem1\_PE.fastqc.log";
    # generate the sequences to remove
    if(defined "$adapter" && -e "$adapter") {
      system "cp $adapter ./Processed/seqToTrim.$stem1.PE.fa";
    } else  {
      system "rm ./Processed/seqToTrim.$stem1.PE.fa" if -e "./Processed/seqToTrim.$stem1.PE.fa";
      system "touch ./Processed/seqToTrim.$stem1.PE.fa";
    }
    # parse the overrepresented sequences
    open my $FIN, "<./FastQCResults/$stem1\_fastqc/fastqc_data.txt" or die "Cannot open fastqc data file: $!\n";
    my @content;
    while(<$FIN>) {
      chomp;
      push @content, $_;
    }
    close $FIN;
    my $i;
    for($i = 0; $i < scalar(@content); ++ $i) {
      if($content[$i] =~ /\>\>Overrepresented sequences/)  {
        $i += 2; my $j = 0;
        while(!($content[$i] =~ /\>\>END\_MODULE/)) {
          system "echo \">\"overrepresented_seq_$j >>./Processed/seqToTrim.$stem1.PE.fa";
          my @decom = split /\t/, $content[$i];
          system "echo $decom[0] >>./Processed/seqToTrim.$stem1.PE.fa";
          ++ $i; ++ $j;
        }
        last;
      }
    }
    open $FIN, "<./FastQCResults/$stem2\_fastqc/fastqc_data.txt" or die "Cannot open fastqc data file: $!\n";
    undef @content;
    while(<$FIN>) {
      chomp;
      push @content, $_;
    }
    close $FIN;
    for($i = 0; $i < scalar(@content); ++ $i) {
      if($content[$i] =~ /\>\>Overrepresented sequences/)  {
        $i += 2; my $j = 0;
        while(!($content[$i] =~ /\>\>END\_MODULE/)) {
          system "echo \">\"overrepresented_seq_$j >>./Processed/seqToTrim.$stem1.PE.fa";
          my @decom = split /\t/, $content[$i];
          system "echo $decom[0] >>./Processed/seqToTrim.$stem1.PE.fa";
          ++ $i; ++ $j;
        }
        last;
      }
    }
    # run Trimmomatic to remove the overrepresented sequences
    system "/usr/bin/time -v java -jar $trimmomaticEXE PE $file1 $file2 ./Processed/$stem1.trimmed.gz ./Processed/$stem1.unpaired.gz ./Processed/$stem2.trimmed.gz ./Processed/$stem2.unpaired.gz ILLUMINACLIP:./Processed/seqToTrim.fa:2:30:10 LEADING:30 TRAILING:30 SLIDINGWINDOW:4:30 MINLEN:35 -threads 8 >&LogFiles/$stem1.PE.trimmomatic.log";
  }
}

